import React, { useState } from 'react';
import { Layout, Plus, Server, Code, Eye, Trash2, Github, FileCode, ImageIcon } from 'lucide-react';
import { Creator } from './components/Creator';
import { BackendDocs } from './components/BackendDocs';
import { Simulator } from './components/Simulator';
import { MagicLink, ViewState } from './types';

export default function App() {
  const [view, setView] = useState<ViewState>('create');
  const [links, setLinks] = useState<MagicLink[]>([]);
  const [activeLink, setActiveLink] = useState<MagicLink | null>(null);

  const handleCreated = (newLink: MagicLink) => {
    setLinks(prev => [newLink, ...prev]);
    setView('dashboard');
  };

  const handleSimulate = (link: MagicLink) => {
    setActiveLink(link);
    setView('simulator');
  };

  const handleDelete = (id: string) => {
    setLinks(prev => prev.filter(l => l.id !== id));
  };

  const handleVisit = (id: string) => {
    setLinks(prev => prev.map(l => l.id === id ? { ...l, visits: l.visits + 1 } : l));
  }

  return (
    <div className="min-h-screen bg-slate-900 text-slate-100 flex flex-col font-sans">
      
      {/* Navigation */}
      <nav className="border-b border-slate-800 bg-slate-900/50 backdrop-blur sticky top-0 z-50">
        <div className="max-w-6xl mx-auto px-4 h-16 flex items-center justify-between">
          <div className="flex items-center gap-3 cursor-pointer" onClick={() => setView('dashboard')}>
            <div className="bg-indigo-600 p-2 rounded-lg">
              <Code size={20} className="text-white" />
            </div>
            <span className="text-xl font-bold tracking-tight">TraceLink</span>
          </div>

          <div className="flex items-center gap-1 md:gap-4">
            <button
              onClick={() => setView('dashboard')}
              className={`px-3 py-2 rounded-md text-sm font-medium transition-colors ${view === 'dashboard' ? 'text-white bg-slate-800' : 'text-slate-400 hover:text-white'}`}
            >
              Dashboard
            </button>
            <button
              onClick={() => setView('create')}
              className={`px-3 py-2 rounded-md text-sm font-medium transition-colors ${view === 'create' ? 'text-white bg-slate-800' : 'text-slate-400 hover:text-white'}`}
            >
              <span className="flex items-center gap-1"><Plus size={14} /> New Link</span>
            </button>
            <button
              onClick={() => setView('docs')}
              className={`px-3 py-2 rounded-md text-sm font-medium transition-colors ${view === 'docs' ? 'text-indigo-400 bg-indigo-900/20 border border-indigo-500/30' : 'text-slate-400 hover:text-white'}`}
            >
              <span className="flex items-center gap-1"><Server size={14} /> Server Setup</span>
            </button>
          </div>
        </div>
      </nav>

      {/* Main Content Area */}
      <main className="flex-1 overflow-auto">
        {view === 'create' && <Creator onCreated={handleCreated} />}
        
        {view === 'docs' && <BackendDocs />}

        {view === 'simulator' && activeLink && (
          <Simulator 
            link={activeLink} 
            onClose={() => setView('dashboard')} 
            onVisit={() => handleVisit(activeLink.id)}
          />
        )}

        {view === 'dashboard' && (
          <div className="max-w-6xl mx-auto p-6 space-y-6">
            <header className="flex items-center justify-between">
              <div>
                <h1 className="text-2xl font-bold text-white">Your TraceLinks</h1>
                <p className="text-slate-400 text-sm mt-1">Manage your active logic-gated endpoints.</p>
              </div>
              <button 
                onClick={() => setView('create')}
                className="bg-indigo-600 hover:bg-indigo-500 text-white px-4 py-2 rounded-lg text-sm font-medium flex items-center gap-2 transition-all shadow-lg shadow-indigo-900/20"
              >
                <Plus size={16} /> Create New
              </button>
            </header>

            {links.length === 0 ? (
              <div className="bg-slate-800/50 border border-slate-700 border-dashed rounded-xl p-12 flex flex-col items-center justify-center text-center space-y-4">
                <div className="w-16 h-16 bg-slate-800 rounded-full flex items-center justify-center text-slate-500">
                  <Layout size={32} />
                </div>
                <div>
                  <h3 className="text-lg font-medium text-white">No links generated yet</h3>
                  <p className="text-slate-400 text-sm max-w-sm mx-auto mt-2">
                    Start by creating a link to an image or HTML page.
                  </p>
                </div>
                <button 
                  onClick={() => setView('create')}
                  className="text-indigo-400 hover:text-indigo-300 text-sm font-medium flex items-center gap-1"
                >
                  Create your first link &rarr;
                </button>
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {links.map(link => (
                  <div key={link.id} className="bg-slate-800 border border-slate-700 rounded-xl overflow-hidden hover:border-slate-600 transition-all shadow-xl group">
                    <div className="h-40 bg-slate-900 relative overflow-hidden flex items-center justify-center">
                      {link.responseType === 'image' ? (
                        <img src={link.imageUrl} alt={link.name} className="w-full h-full object-cover opacity-60 group-hover:opacity-80 transition-opacity" />
                      ) : (
                        <div className="text-slate-600 flex flex-col items-center gap-2">
                          <FileCode size={40} />
                          <span className="text-xs font-mono">HTML CONTENT</span>
                        </div>
                      )}
                      
                      <div className="absolute top-3 right-3 flex gap-2">
                         <div className="bg-black/60 backdrop-blur text-xs font-mono px-2 py-1 rounded text-white border border-white/10">
                          {link.language === 'javascript' ? 'Node' : 'Py'}
                        </div>
                      </div>
                      
                      <div className="absolute top-3 left-3">
                         {link.responseType === 'html' ? (
                           <div className="bg-emerald-500/80 backdrop-blur text-xs font-bold px-2 py-1 rounded text-white flex items-center gap-1">
                             <FileCode size={12} /> HTML
                           </div>
                         ) : (
                           <div className="bg-indigo-500/80 backdrop-blur text-xs font-bold px-2 py-1 rounded text-white flex items-center gap-1">
                             <ImageIcon size={12} /> IMG
                           </div>
                         )}
                      </div>

                    </div>
                    <div className="p-5">
                      <div className="flex justify-between items-start mb-4">
                        <div>
                          <h3 className="font-semibold text-white truncate pr-4">{link.name}</h3>
                          <div className="text-xs text-slate-500 font-mono mt-1 flex items-center gap-2">
                            <span>ID: {link.id}</span>
                            <span className="w-1 h-1 bg-slate-600 rounded-full" />
                            <span>Visits: {link.visits}</span>
                          </div>
                        </div>
                      </div>
                      
                      <div className="flex gap-2 mt-4">
                        <button 
                          onClick={() => handleSimulate(link)}
                          className="flex-1 bg-indigo-600/10 hover:bg-indigo-600/20 text-indigo-400 border border-indigo-500/30 py-2 rounded-lg text-sm font-medium transition-colors flex items-center justify-center gap-2"
                        >
                          <Eye size={16} /> Simulate
                        </button>
                        <button 
                          onClick={() => handleDelete(link.id)}
                          className="p-2 text-slate-500 hover:text-red-400 hover:bg-red-500/10 rounded-lg transition-colors"
                          title="Delete"
                        >
                          <Trash2 size={18} />
                        </button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}
      </main>

    </div>
  );
}