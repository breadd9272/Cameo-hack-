import { MagicLink, LogEntry } from '../types';

export const generateId = () => Math.random().toString(36).substring(2, 10);

export const DEFAULT_JS_CODE = `// Available globals: 
// context = { ip, userAgent, timestamp }
// tools = { log(msg), allow() }

const hour = new Date(context.timestamp).getHours();

tools.log(\`Visitor IP: \${context.ip}\`);
tools.log(\`Access time: \${hour}:00\`);

if (hour >= 18 || hour < 6) {
    tools.log("It's night time. Access granted.");
    tools.allow(); 
} else {
    tools.log("It's day time. Logging visit but serving image anyway.");
    tools.allow();
}
`;

export const DEFAULT_PYTHON_CODE = `# Available globals:
# context = { 'ip': str, 'user_agent': str, 'timestamp': str }
# tools.log(msg)
# tools.allow()

import datetime

def handle_request():
    tools.log(f"Processing request from {context['ip']}")
    
    # Simple logic example
    if "Mozilla" in context['user_agent']:
        tools.log("Browser detected")
    
    tools.allow()

handle_request()
`;

// This function simulates the Node.js VM execution for JavaScript
// strictly for demonstration purposes in the UI.
export const simulateExecution = async (
  code: string, 
  onLog: (entry: LogEntry) => void,
  language: 'javascript' | 'python' = 'javascript'
): Promise<boolean> => {
  return new Promise((resolve) => {
    const context = {
      ip: '192.168.1.42',
      userAgent: navigator.userAgent,
      timestamp: new Date().toISOString()
    };
    
    let allowed = false;

    // Common tools
    const tools = {
      log: (msg: string) => onLog({ timestamp: new Date().toLocaleTimeString(), level: 'info', message: String(msg) }),
      allow: () => { allowed = true; },
      webhook: (url: string) => onLog({ timestamp: new Date().toLocaleTimeString(), level: 'warn', message: `Webhook triggered: ${url}` }),
    };

    if (language === 'python') {
      onLog({ timestamp: new Date().toLocaleTimeString(), level: 'system', message: 'Initializing Python 3.9 environment...' });
      
      setTimeout(() => {
        try {
          // Simple regex-based mock parser for Python to make it feel responsive
          const lines = code.split('\n');
          
          lines.forEach(line => {
            const trimmed = line.trim();
            // Match tools.log("...") or tools.log('...')
            const logMatch = trimmed.match(/tools\.log\((["'])(.*?)\1\)/);
            if (logMatch) {
              tools.log(logMatch[2]);
            }

            // Match print("...")
            const printMatch = trimmed.match(/print\((["'])(.*?)\1\)/);
            if (printMatch) {
              onLog({ timestamp: new Date().toLocaleTimeString(), level: 'info', message: `[STDOUT] ${printMatch[2]}` });
            }

            if (trimmed.includes('tools.allow()')) {
              tools.allow();
            }
          });

          onLog({ timestamp: new Date().toLocaleTimeString(), level: 'system', message: 'Script finished.' });
          resolve(true); // Python mock always succeeds for demo
        } catch (e: any) {
          onLog({ timestamp: new Date().toLocaleTimeString(), level: 'error', message: `Python Error: ${e.message}` });
          resolve(false);
        }
      }, 1000);
      return;
    }

    // JavaScript Execution
    onLog({ timestamp: new Date().toLocaleTimeString(), level: 'system', message: 'Initializing Node.js sandbox...' });
    
    setTimeout(() => {
      try {
        onLog({ timestamp: new Date().toLocaleTimeString(), level: 'system', message: 'Executing user script...' });
        
        // Mocking 'require' to prevent crashes if user tries to import modules in this browser demo
        const mockRequire = (moduleName: string) => {
          onLog({ timestamp: new Date().toLocaleTimeString(), level: 'warn', message: `[Mock] require('${moduleName}') ignored in browser simulation.` });
          return {}; 
        };

        // DANGEROUS IN REAL APP: simplified for this client-side demo
        const safeRun = new Function('context', 'tools', 'require', code);
        safeRun(context, tools, mockRequire);

        setTimeout(() => {
          if (allowed) {
            onLog({ timestamp: new Date().toLocaleTimeString(), level: 'system', message: 'Script finished. Access GRANTED.' });
            resolve(true);
          } else {
            onLog({ timestamp: new Date().toLocaleTimeString(), level: 'warn', message: 'Script finished. No allow() called (Simulated defaults to show image anyway).' });
            resolve(true); 
          }
        }, 800);

      } catch (e: any) {
        onLog({ timestamp: new Date().toLocaleTimeString(), level: 'error', message: `Runtime Error: ${e.message}` });
        resolve(false);
      }
    }, 1000);
  });
};