export interface MagicLink {
  id: string;
  name: string;
  code: string;
  language: 'javascript' | 'python';
  responseType: 'image' | 'html'; 
  imageUrl?: string;
  htmlContent?: string; 
  injectionCode?: string; // New field for client-side injection
  createdAt: number;
  visits: number;
}

export type ViewState = 'dashboard' | 'create' | 'simulator' | 'docs';

export interface LogEntry {
  timestamp: string;
  level: 'info' | 'warn' | 'error' | 'system';
  message: string;
}