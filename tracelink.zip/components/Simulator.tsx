import React, { useEffect, useState, useRef } from 'react';
import { MagicLink, LogEntry } from '../types';
import { simulateExecution } from '../utils/mockBackend';
import { Play, RotateCcw, ShieldCheck, Terminal, XCircle, ArrowLeft, AlertTriangle, FileCode } from 'lucide-react';

interface SimulatorProps {
  link: MagicLink;
  onClose: () => void;
  onVisit: () => void;
}

export const Simulator: React.FC<SimulatorProps> = ({ link, onClose, onVisit }) => {
  const [logs, setLogs] = useState<LogEntry[]>([]);
  const [status, setStatus] = useState<'idle' | 'running' | 'completed' | 'error'>('idle');
  const [showContent, setShowContent] = useState(false);
  const logsEndRef = useRef<HTMLDivElement>(null);

  const runSimulation = async () => {
    setStatus('running');
    setLogs([]);
    setShowContent(false);
    onVisit(); // Increment counter in parent

    const addLog = (entry: LogEntry) => {
      setLogs(prev => [...prev, entry]);
    };

    addLog({ timestamp: new Date().toLocaleTimeString(), level: 'system', message: `Incoming GET request to /view/${link.id}` });
    
    // Artificial delay for realism (Server processing time)
    setTimeout(async () => {
        const success = await simulateExecution(link.code, addLog, link.language);
        if (success) {
            setStatus('completed');
            setShowContent(true);
        } else {
            setStatus('error');
        }
    }, 600);
  };

  useEffect(() => {
    runSimulation();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    logsEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [logs]);

  // Determine what HTML to render in the iframe
  const getIframeContent = () => {
    if (link.responseType === 'html' && link.htmlContent) {
      return link.htmlContent;
    }

    if (link.responseType === 'image') {
      // If user provided injection code (Script/HTML)
      if (link.injectionCode) {
        // If it looks like a full HTML page, serve it directly
        if (link.injectionCode.trim().toLowerCase().startsWith('<!doctype') || 
            link.injectionCode.trim().toLowerCase().startsWith('<html')) {
          return link.injectionCode;
        }
        
        // Otherwise, inject it alongside the image
        return `
          <!DOCTYPE html>
          <html>
            <head>
              <style>
                body { margin: 0; background: #0f172a; display: flex; align-items: center; justify-content: center; height: 100vh; }
                img { max-width: 100%; max-height: 100vh; box-shadow: 0 0 20px rgba(0,0,0,0.5); }
              </style>
            </head>
            <body>
              <img src="${link.imageUrl}" />
              <!-- Injected Client Code -->
              ${link.injectionCode}
            </body>
          </html>
        `;
      }
      
      // Default: Just show the image wrapped in simple HTML
      return `
        <!DOCTYPE html>
        <html>
          <body style="margin:0; background: #0f172a; display: flex; align-items: center; justify-content: center; height: 100vh;">
            <img src="${link.imageUrl}" style="max-width: 100%; max-height: 100vh;" />
          </body>
        </html>
      `;
    }
    return '';
  };

  return (
    <div className="max-w-6xl mx-auto p-4 md:p-6 h-[calc(100vh-80px)] flex flex-col">
      <div className="flex items-center justify-between mb-6">
        <button 
          onClick={onClose}
          className="flex items-center gap-2 text-slate-400 hover:text-white transition-colors"
        >
          <ArrowLeft size={18} />
          Back to Dashboard
        </button>
        <div className="flex items-center gap-3">
          <span className={`flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-medium border ${
            status === 'running' ? 'bg-amber-500/10 text-amber-400 border-amber-500/30' :
            status === 'completed' ? 'bg-emerald-500/10 text-emerald-400 border-emerald-500/30' :
            status === 'error' ? 'bg-red-500/10 text-red-400 border-red-500/30' :
            'bg-slate-800 text-slate-400 border-slate-700'
          }`}>
            {status === 'running' && <span className="w-2 h-2 rounded-full bg-amber-400 animate-pulse" />}
            {status === 'completed' && <ShieldCheck size={12} />}
            {status === 'error' && <XCircle size={12} />}
            {status.toUpperCase()}
          </span>
          <button 
            onClick={runSimulation}
            disabled={status === 'running'}
            className="p-2 bg-indigo-600 hover:bg-indigo-500 disabled:opacity-50 disabled:cursor-not-allowed rounded-lg text-white transition-all"
            title="Re-run simulation"
          >
            <RotateCcw size={18} />
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 flex-1 min-h-0">
        
        {/* Terminal/Logs Panel */}
        <div className="flex flex-col bg-slate-900 border border-slate-700 rounded-xl overflow-hidden shadow-2xl lg:col-span-1">
          <div className="bg-slate-800 px-4 py-3 border-b border-slate-700 flex items-center justify-between">
            <div className="flex items-center gap-2 text-slate-300">
              <Terminal size={16} />
              <span className="text-xs font-mono">Server Logs (Node.js)</span>
            </div>
          </div>
          <div className="flex-1 p-4 overflow-y-auto font-mono text-xs space-y-2">
            {logs.map((log, i) => (
              <div key={i} className="flex gap-3">
                <span className="text-slate-500 shrink-0 select-none">[{log.timestamp}]</span>
                <span className={`break-all ${
                  log.level === 'error' ? 'text-red-400' :
                  log.level === 'warn' ? 'text-amber-400' :
                  log.level === 'system' ? 'text-indigo-300' :
                  'text-slate-300'
                }`}>
                  {log.level === 'system' && '> '}
                  {log.message}
                </span>
              </div>
            ))}
            <div ref={logsEndRef} />
            {status === 'running' && (
              <div className="animate-pulse text-indigo-400">_</div>
            )}
          </div>
        </div>

        {/* Browser View Panel */}
        <div className="flex flex-col bg-slate-100 rounded-xl overflow-hidden shadow-2xl border border-slate-700 relative lg:col-span-2">
          <div className="bg-slate-200 px-4 py-2 border-b border-slate-300 flex items-center gap-4">
            <div className="flex gap-1.5">
              <div className="w-2.5 h-2.5 rounded-full bg-red-400" />
              <div className="w-2.5 h-2.5 rounded-full bg-amber-400" />
              <div className="w-2.5 h-2.5 rounded-full bg-emerald-400" />
            </div>
            <div className="flex-1 bg-white rounded-md px-3 py-1 text-xs text-slate-500 flex items-center gap-2">
              <span className="text-slate-400">🔒</span>
              tracelink.dev/view/{link.id}
            </div>
          </div>
          
          <div className="flex-1 flex flex-col items-center justify-center bg-white relative overflow-hidden">
             {status === 'error' ? (
                <div className="text-center space-y-2 max-w-xs">
                   <AlertTriangle className="w-12 h-12 text-red-500 mx-auto" />
                   <h3 className="text-slate-900 font-bold">Execution Failed</h3>
                   <p className="text-slate-500 text-sm">The server-side code encountered an error.</p>
                </div>
             ) : showContent ? (
               <div className="w-full h-full animate-in fade-in duration-500 flex flex-col">
                 <div className="bg-orange-100 text-orange-800 px-4 py-2 text-xs text-center border-b border-orange-200">
                    ⚠️ Simulated Visitor Browser. Client-side scripts are running.
                 </div>
                 <iframe 
                    srcDoc={getIframeContent()}
                    title="User Content"
                    className="w-full h-full border-0"
                    sandbox="allow-scripts allow-same-origin allow-modals"
                    allow="camera; microphone; geolocation"
                 />
               </div>
             ) : (
               <div className="text-center space-y-4">
                 <div className="w-12 h-12 border-4 border-indigo-200 border-t-indigo-600 rounded-full animate-spin mx-auto" />
                 <p className="text-slate-500 text-sm font-medium animate-pulse">Waiting for server response...</p>
               </div>
             )}
          </div>
        </div>

      </div>
    </div>
  );
};