import React from 'react';
import { Copy, Terminal, FolderTree } from 'lucide-react';

const SERVER_CODE = `const express = require('express');
const multer = require('multer');
const { NodeVM } = require('vm2');
const fs = require('fs');
const path = require('path');
const app = express();
const upload = multer({ dest: 'uploads/' });

// Database simulation (use SQLite/MongoDB in production)
const DB = {
  links: {} // { id: { code, imagePath, mimeType } }
};

app.post('/api/create', upload.single('image'), (req, res) => {
  const id = Math.random().toString(36).substring(7);
  DB.links[id] = {
    code: req.body.code,
    imagePath: req.file.path,
    mimeType: req.file.mimetype
  };
  res.json({ url: \`http://localhost:3000/view/\${id}\`, id });
});

app.get('/view/:id', (req, res) => {
  const item = DB.links[req.params.id];
  if (!item) return res.status(404).send('Not Found');

  // Sandbox Setup
  const vm = new NodeVM({
    console: 'redirect',
    sandbox: {
      context: {
        ip: req.ip,
        userAgent: req.get('User-Agent'),
        timestamp: new Date().toISOString()
      },
      tools: {
        allow: () => { req.isAllowed = true; },
        log: (msg) => console.log(\`[UserLog]: \${msg}\`)
      }
    },
    require: { external: false } // Block external requires
  });

  try {
    console.log(\`[System] Executing logic for \${req.params.id}\`);
    
    // Execute User Code
    vm.run(item.code);

    // Check if user code allowed the request
    // In this simple example, we just serve image after execution
    // unless you add logic to block it.
    
    res.setHeader('Content-Type', item.mimeType);
    fs.createReadStream(item.imagePath).pipe(res);

  } catch (err) {
    console.error('Execution Error:', err);
    res.status(500).send('Script Error: ' + err.message);
  }
});

app.listen(3000, () => console.log('TraceLink Server running on port 3000'));
`;

const PACKAGE_JSON = `{
  "name": "tracelink-backend",
  "version": "1.0.0",
  "main": "server.js",
  "dependencies": {
    "express": "^4.18.2",
    "multer": "^1.4.5-lts.1",
    "vm2": "^3.9.19"
  }
}`;

const CodeBlock = ({ title, code, lang = 'javascript' }: { title: string, code: string, lang?: string }) => {
  const [copied, setCopied] = React.useState(false);
  
  const handleCopy = () => {
    navigator.clipboard.writeText(code);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="mb-8 border border-slate-700 rounded-lg overflow-hidden bg-slate-900 shadow-lg">
      <div className="flex items-center justify-between px-4 py-2 bg-slate-800 border-b border-slate-700">
        <span className="text-sm font-medium text-slate-300 font-mono">{title}</span>
        <button 
          onClick={handleCopy}
          className="flex items-center gap-2 text-xs text-slate-400 hover:text-white transition-colors"
        >
          <Copy size={14} />
          {copied ? 'Copied!' : 'Copy'}
        </button>
      </div>
      <div className="p-4 overflow-x-auto">
        <pre className="text-sm text-indigo-300 font-mono leading-relaxed whitespace-pre">
          {code}
        </pre>
      </div>
    </div>
  );
};

export const BackendDocs = () => {
  return (
    <div className="max-w-4xl mx-auto p-6 space-y-8">
      <header className="mb-10">
        <h2 className="text-3xl font-bold text-white mb-2">Backend Implementation</h2>
        <p className="text-slate-400">
          This frontend tool is a prototype. To deploy the actual logic execution engine, use the Node.js code below.
        </p>
      </header>

      <section>
        <div className="flex items-center gap-2 mb-4 text-xl font-semibold text-white">
          <FolderTree className="text-indigo-400" />
          <h3>Project Structure</h3>
        </div>
        <div className="bg-slate-800 p-6 rounded-lg border border-slate-700 font-mono text-sm text-slate-300">
          tracelink-server/<br/>
          ├── uploads/ <span className="text-slate-500"># Image storage</span><br/>
          ├── package.json <span className="text-slate-500"># Dependencies</span><br/>
          └── server.js <span className="text-slate-500"># Main application logic</span>
        </div>
      </section>

      <section>
        <div className="flex items-center gap-2 mb-4 text-xl font-semibold text-white">
          <Terminal className="text-indigo-400" />
          <h3>1. Setup Dependencies</h3>
        </div>
        <CodeBlock title="package.json" code={PACKAGE_JSON} lang="json" />
      </section>

      <section>
        <div className="flex items-center gap-2 mb-4 text-xl font-semibold text-white">
          <Terminal className="text-indigo-400" />
          <h3>2. Server Code</h3>
        </div>
        <p className="text-slate-400 mb-4">
          This Express server uses <code>vm2</code> for sandboxing user code. It intercepts the request, runs the code, and then streams the image.
        </p>
        <CodeBlock title="server.js" code={SERVER_CODE} />
      </section>
      
      <section className="bg-indigo-900/20 border border-indigo-500/30 p-6 rounded-lg">
        <h4 className="text-indigo-300 font-semibold mb-2">Security Note</h4>
        <p className="text-sm text-indigo-200/70">
          Running arbitrary code is risky. The implementation above uses <code>vm2</code> for sandboxing, 
          but for production environments, consider using Docker containers or Firecracker microVMs 
          for stronger isolation.
        </p>
      </section>
    </div>
  );
};